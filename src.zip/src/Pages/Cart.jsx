import { faBackward, faTrash } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React from 'react'
import { Link } from 'react-router-dom'


function Cart() {
  return (
    <>
    <div className='pt-32'>
    <h1 className='text-center text-fuchsia-700 text-4xl '>Cart</h1>
    <div className='md:grid grid-cols-[2fr_1fr] '>
      <div className='p-10'>
        <table className='border border-gray-200 w-full shadow text-center'>
          <thead>
            <tr>
              <th className='bg-gray-600 p-4 border border-gray-200 text-white '>#</th>
              <th className='bg-gray-600 p-4 border border-gray-200 text-white '>Title</th>
              <th className='bg-gray-600 p-4 border border-gray-200 text-white '>Image</th>
              <th className='bg-gray-600 p-4 border border-gray-200 text-white '>Price</th>
              <th className='bg-gray-600 p-4 border border-gray-200 text-white '>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className='p-4 border border-gray-200'>1</td>
              <td className='p-4 border border-gray-200'>Demo</td>
              <td className='p-4 border border-gray-200 flex justify-center'><img src="https://static.vecteezy.com/system/resources/thumbnails/017/054/078/small/headphones-design-3d-rendering-for-product-mockup-free-png.png" alt=" NO IMAGE" style={{height:"100px",width:"150px"}}/></td>
              <td className='p-4 border border-gray-200'>$ 88</td>
              <td className='p-4 border border-gray-200'><button className='bg-red-600 px-5 py-3 text-white rounded hover:text-red-600 hover:bg-white hover:border border-red-600'><FontAwesomeIcon icon={faTrash} /></button></td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className='p-10'>
        <div className='shadow-lg p-5'>
          <h1 className='text-center text-2xl '>Cart Summary</h1>
          <p className='mt-4 '>Total number of items : 3</p>
          <p className='mt-2'>Grand Total : $45</p>
          <button className='p-3 bg-green-600 w-full mt-3 rounded text-white hover:border border-green-600 hover:text-green-600 hover:bg-white'>Checkout</button>
        </div>
      </div>
    </div>

    <div className='md:grid grid-cols-3'>
      <div></div>
      <div className='mt-44 mb-28 text-center'>
        <img src="https://c9nutrition.com/img/empty-cart-yellow.png" alt="" className='w-full h-auto'/>
<Link to = {'/'}>        <button className='p-3 bg-green-600  mt-3 rounded text-white hover:border border-green-600 hover:text-green-600 hover:bg-white'><FontAwesomeIcon icon={faBackward} /> Back Home</button>
</Link>
      </div>
      <div></div>
    </div>
    </div>
    </>
  )
}

export default Cart