import { faHeart , faCartShopping} from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React from 'react'

function Home() {
  return (
    <>
      <div className="pt-32 px-8 mb-10 md:grid grid-cols-4">
       <div className="p-2">
       <div className='border shadow-lg p-5'>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEw2ce40BkWdXvgMffW8BefaU8jogoAzSNDA&s" alt="No image" className='w-full h-48' />
          <h4 className='text-center text-2xl m-3'>Title</h4>
          <p className='text-justify'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia in, debitis dicta iste a eos, doloremque officia quisquam quas voluptate praesenarum. Atque.</p>
          <p className='text-xl my-3 '>Price: <span className='text-violet-600'>$99</span></p>
          <div className='m-2 flex justify-between'>
            <button className='py-2 px-4 text-white bg-red-600 rounded'><FontAwesomeIcon icon={faHeart} /></button>
            <button className=' py-2 px-4 text-white bg-green-600 rounded'><FontAwesomeIcon icon={faCartShopping} /></button>
          </div>
        </div>
       </div>
       <div className="p-2">
       <div className='border shadow-lg p-5'>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEw2ce40BkWdXvgMffW8BefaU8jogoAzSNDA&s" alt="No image" className='w-full h-48' />
          <h4 className='text-center text-2xl m-3'>Title</h4>
          <p className='text-justify'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia in, debitis dicta iste a eos, doloremque officia quisquam quas voluptate praesenarum. Atque.</p>
          <p className='text-xl my-3 '>Price: <span className='text-violet-600'>$99</span></p>
          <div className='m-2 flex justify-between'>
            <button className='py-2 px-4 text-white bg-red-600 rounded'><FontAwesomeIcon icon={faHeart} /></button>
            <button className=' py-2 px-4 text-white bg-green-600 rounded'><FontAwesomeIcon icon={faCartShopping} /></button>
          </div>
        </div>
       </div>
       <div className="p-2">
       <div className='border shadow-lg p-5'>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEw2ce40BkWdXvgMffW8BefaU8jogoAzSNDA&s" alt="No image" className='w-full h-48' />
          <h4 className='text-center text-2xl m-3'>Title</h4>
          <p className='text-justify'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia in, debitis dicta iste a eos, doloremque officia quisquam quas voluptate praesenarum. Atque.</p>
          <p className='text-xl my-3 '>Price: <span className='text-violet-600'>$99</span></p>
          <div className='m-2 flex justify-between'>
            <button className='py-2 px-4 text-white bg-red-600 rounded hover:border border-red-600 hover:text-red-600 hover:bg-white'><FontAwesomeIcon icon={faHeart} /></button>
            <button className=' py-2 px-4 text-white bg-green-600 rounded hover:border border-green-600 hover:text-green-600 hover:bg-white'><FontAwesomeIcon icon={faCartShopping} /></button>
          </div>
        </div>
       </div>
       <div className="p-2">
       <div className='border shadow-lg p-5'>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEw2ce40BkWdXvgMffW8BefaU8jogoAzSNDA&s" alt="No image" className='w-full h-48' />
          <h4 className='text-center text-2xl m-3'>Title</h4>
          <p className='text-justify'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia in, debitis dicta iste a eos, doloremque officia quisquam quas voluptate praesenarum. Atque.</p>
          <p className='text-xl my-3 '>Price: <span className='text-violet-600'>$99</span></p>
          <div className='m-2 flex justify-between'>
            <button className='py-2 px-4 text-white bg-red-600 rounded'><FontAwesomeIcon icon={faHeart} /></button>
            <button className=' py-2 px-4 text-white bg-green-600 rounded'><FontAwesomeIcon icon={faCartShopping} /></button>
          </div>
        </div>
       </div>
      </div>
    </>
  )
}

export default Home