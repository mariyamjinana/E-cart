import React from 'react'
import { faHeart , faCartShopping} from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

function Wishlist() {
  return (
    <>
    <div className='pt-32'>
      <h1 className='text-center text-fuchsia-700 text-4xl '>Wishlist</h1>
    <div className=" px-8 mb-10 md:grid grid-cols-4 my-5">
       <div className="p-2">
       <div className='border shadow-lg p-5'>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEw2ce40BkWdXvgMffW8BefaU8jogoAzSNDA&s" alt="No image" className='w-full h-48' />
          <h4 className='text-center text-2xl m-3'>Title</h4>
          <p className='text-justify'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia in, debitis dicta iste a eos, doloremque officia quisquam quas voluptate praesenarum. Atque.</p>
          <p className='text-xl my-3 '>Price: <span className='text-violet-600'>$99</span></p>
          <div className='m-2 flex justify-between'>
            <button className='py-2 px-4 text-white bg-red-600 rounded'><FontAwesomeIcon icon={faHeart} /></button>
            <button className=' py-2 px-4 text-white bg-green-600 rounded'><FontAwesomeIcon icon={faCartShopping} /></button>
          </div>
        </div>
       </div>
       <div className="p-2">
       <div className='border shadow-lg p-5'>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEw2ce40BkWdXvgMffW8BefaU8jogoAzSNDA&s" alt="No image" className='w-full h-48' />
          <h4 className='text-center text-2xl m-3'>Title</h4>
          <p className='text-justify'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia in, debitis dicta iste a eos, doloremque officia quisquam quas voluptate praesenarum. Atque.</p>
          <p className='text-xl my-3 '>Price: <span className='text-violet-600'>$99</span></p>
          <div className='m-2 flex justify-between'>
            <button className='py-2 px-4 text-white bg-red-600 rounded'><FontAwesomeIcon icon={faHeart} /></button>
            <button className=' py-2 px-4 text-white bg-green-600 rounded'><FontAwesomeIcon icon={faCartShopping} /></button>
          </div>
        </div>
       </div>
       <div className="p-2">
       <div className='border shadow-lg p-5'>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEw2ce40BkWdXvgMffW8BefaU8jogoAzSNDA&s" alt="No image" className='w-full h-48' />
          <h4 className='text-center text-2xl m-3'>Title</h4>
          <p className='text-justify'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia in, debitis dicta iste a eos, doloremque officia quisquam quas voluptate praesenarum. Atque.</p>
          <p className='text-xl my-3 '>Price: <span className='text-violet-600'>$99</span></p>
          <div className='m-2 flex justify-between'>
            <button className='py-2 px-4 text-white bg-red-600 rounded'><FontAwesomeIcon icon={faHeart} /></button>
            <button className=' py-2 px-4 text-white bg-green-600 rounded'><FontAwesomeIcon icon={faCartShopping} /></button>
          </div>
        </div>
       </div>
       <div className="p-2">
       <div className='border shadow-lg p-5'>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEw2ce40BkWdXvgMffW8BefaU8jogoAzSNDA&s" alt="No image" className='w-full h-48' />
          <h4 className='text-center text-2xl m-3'>Title</h4>
          <p className='text-justify'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia in, debitis dicta iste a eos, doloremque officia quisquam quas voluptate praesenarum. Atque.</p>
          <p className='text-xl my-3 '>Price: <span className='text-violet-600'>$99</span></p>
          <div className='m-2 flex justify-between'>
            <button className='py-2 px-4 text-white bg-red-600 rounded'><FontAwesomeIcon icon={faHeart} /></button>
            <button className=' py-2 px-4 text-white bg-green-600 rounded'><FontAwesomeIcon icon={faCartShopping} /></button>
          </div>
        </div>
       </div>
      </div>
    </div>
    <div className='md:grid grid-cols-3'>
      <div></div>
      <div className='mt-44 mb-28'>
        <img src="https://i.pinimg.com/originals/f6/e4/64/f6e464230662e7fa4c6a4afb92631aed.png" alt="" className='w-full h-auto'/>
      </div>
      <div></div>
    </div>
    </>
  )
}

export default Wishlist